downSize = 64

trainPath = './train.txt'
valPath = './val.txt'


#trainNum = 17714
trainNum = 17714
valNum = 1969

numClass = 3
classes = {"NiCT":0,"pCT":1,"nCT":2}